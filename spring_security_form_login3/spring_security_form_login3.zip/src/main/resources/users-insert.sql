insert into  users(user_id,password,email,enabled) values(?,'1111',?,?);
insert into  users(user_id,password,email,enabled) values(?,?,?,?);
insert  into  users_authority   (user_id, authority) values (?, ?)
package com.springboot.security.oauth.domain.enums;

public enum Role {
    ROLE_USER
}

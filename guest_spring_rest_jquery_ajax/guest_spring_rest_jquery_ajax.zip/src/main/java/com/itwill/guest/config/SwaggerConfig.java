package com.itwill.guest.config;

public class SwaggerConfig {
	/*
	@Bean
	public GroupedOpenApi chatOpenApi() {
		String[] paths = { "/v1/**" };
		return GroupedOpenApi.builder().group("COUPLE API v1").pathsToMatch(paths).build();
	}
	*/

}

	http://localhost/guest_spring_rest_jquery_ajax/swagger-ui/index.html
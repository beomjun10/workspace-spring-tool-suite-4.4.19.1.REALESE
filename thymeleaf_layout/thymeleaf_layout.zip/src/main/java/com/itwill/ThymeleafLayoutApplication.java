package com.itwill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafLayoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafLayoutApplication.class, args);
	}

}

package com.itwill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafLayoutApplicationTests {

	@Test
	void contextLoads() {
	}

}

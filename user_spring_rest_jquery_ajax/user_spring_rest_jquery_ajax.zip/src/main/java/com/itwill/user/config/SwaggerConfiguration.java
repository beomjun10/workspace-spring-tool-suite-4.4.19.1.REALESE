package com.itwill.user.config;


import org.springframework.context.annotation.Configuration;


@Configuration

public class SwaggerConfiguration {

  
}

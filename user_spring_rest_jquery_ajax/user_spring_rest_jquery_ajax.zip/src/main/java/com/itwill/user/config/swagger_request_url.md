
	http://localhost/user_spring_rest_jquery_ajax/swagger-ui/index.html

function navigate() {
/********* path *********
	#/user_login_form
	#/user_write_form
	#/user_logout_action
	#/user_view
	#/user_write_action
	#/user_login_action
	#/user_modify_form
	#/user_delete_action
**************************/
	
	const path = '';
	let html = '';
	if (path == '/user_main') {
		/****************user_main start******************/
	
	} else if (path == '/user_write_form') {
		/**************** /user_write_form ************/
		
	/*###############################[form validator plugin]##########################
	form validator
	 - HOMEPAGE :   https://jqueryvalidation.org/
	 - API      :   https://jqueryvalidation.org/validate/
		1. $(form).validate() function은 form loading시에 미리 호출되어있어야한다.
		2. var validator=$(form).validate(); 실행후 반환되는 validator 객체를 사용한다.
	#################################################################################*/
	
	} else if (path == '/user_login_form') {
		/**************** /user_login_form************/
	
	} else if (path == '/user_login_action') {
		/**************** /user_login_action**********/
		
		
	} else if (path == '/user_logout_action') {
		/**************** /user_logout_action*********/
		
	} else if (path == '/user_write_action') {
		/**************** /user_write_action**********/
		
	} else if (path.startsWith('/user_view/')) {
		/**************** /user_view/userId **********/
		
	} else if (path.startsWith('/user_modify_form/')) {
		/**************** /user_modify_form **********/
		
	} else if (path.startsWith('/user_modify_action/')) {
		/**************** /user_modify_action/userId ******************/
		
	} else if (path.startsWith('/user_delete_action/')) {
		/**************** /user_delete_action/userId ******************/
	
	} else {
		
	}
}//navigate





/*********jQuery Ajax Global Event ************/
$(document).ajaxStart(function() {
	$("<div id='loading'>loading...</div>").insertBefore('#content');
	$('#loading').show();
});
$(document).ajaxComplete(function() {
	$('#loading').hide();
	$('#loading').remove();
});




	http://localhost/spring_web_application_rest_jquery_ajax/swagger-ui/index.html
package com.itwill.jpa.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itwill.jpa.dao.ProductDao;
import com.itwill.jpa.dto.ProductDto;
import com.itwill.jpa.dto.ProductResponseDto;
import com.itwill.jpa.dto.ProductUpdateDto;
import com.itwill.jpa.entity.Product;


public class ProductServiceImpl implements ProductService {
	

	@Override
	public List<ProductResponseDto> products() {
		List<ProductResponseDto> productDtoList = new ArrayList<ProductResponseDto>();
		return productDtoList;
	}

	@Override
	public ProductResponseDto getProduct(Long number) {
		ProductResponseDto productResponseDto = new ProductResponseDto();
		return productResponseDto;
	}

	@Override
	public ProductResponseDto saveProduct(ProductDto productDto) {
		ProductResponseDto productResponseDto = new ProductResponseDto();
		return productResponseDto;
	}

	@Override
	public ProductResponseDto updateProduct(ProductUpdateDto productUpdateDto) throws Exception {
		ProductResponseDto productResponseDto = new ProductResponseDto();
		return productResponseDto;
	}

	@Override
	public void deleteProduct(Long no) throws Exception {
		
	}

}

package com.itwill.jpa.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.itwill.jpa.dto.ProductResponseDto;
import com.itwill.jpa.entity.Product;
import com.itwill.jpa.repository.ProductRepository;


public class ProductDaoImpl implements ProductDao {

	public List<Product> selectList() {

		return null;
	}

	@Override
	public Product insertProduct(Product product) {
		Product savedProduct = null;
		return savedProduct;
	}

	@Override
	public Product selectProduct(Long no) {
		Product selectedProduct = null;
		return selectedProduct;
	}

	@Override
	public Product updateProduct(Product updateProduct) {
		Product updatedProduct = null;
		return updatedProduct;
	}

	@Override
	public void deleteProduct(Long number) throws Exception {
		Optional<Product> selectedProduct = null;
	}

}
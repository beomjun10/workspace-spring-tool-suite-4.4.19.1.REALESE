package com.itwill.jpa.dto;


public class ProductUpdateDto {
    private Long no;
    private String name;
  

}

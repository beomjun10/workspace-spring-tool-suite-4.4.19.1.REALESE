package com.itwill.shop.controller;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class ShopController {
	@GetMapping(value = {"/","/index"})
	public String index(HttpSession session) {
		
		String sUserId=(String)session.getAttribute("sUserId");
		return "index";
	}
	@GetMapping("/shop-grid-ns")
	public String shop_grid_ns() {
		return "shop-grid-ns";
	}
	
}

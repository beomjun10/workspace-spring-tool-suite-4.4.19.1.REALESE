insert  into product(no,name,price,stock,created_at,updated_at) values(product_no_seq.nextval,'새우깡',3000,10,sysdate,sysdate);
insert  into product(no,name,price,stock,created_at,updated_at) values(product_no_seq.nextval,'감자깡',2000,20,sysdate,sysdate);
insert  into product(no,name,price,stock,created_at,updated_at) values(product_no_seq.nextval,'양파링',1000,30,sysdate,sysdate);
insert  into product(no,name,price,stock,created_at,updated_at) values(product_no_seq.nextval,'꼬북칩',4000,40,sysdate,sysdate);
insert  into product(no,name,price,stock,created_at,updated_at) values(product_no_seq.nextval,'꼬깔콘',8000,50,sysdate,sysdate);